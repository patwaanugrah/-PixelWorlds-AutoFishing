# PW Auto Fishing v1.2 — test build

This is **not a full automatic fishing bot**. This release fixes missing overlay by explicitly starting OverlayService, has START/STOP state, test hook tap, and MediaProjection capture lifecycle. The image listener only counts frames; no visual detection/auto fishing has been implemented or tested.

## Build from GitHub
Upload this ZIP to repository root, then replace `.github/workflows/build-apk.yml` with workflow below or upload the bundled workflow. Build artifact will be a debug APK.

## On POCO F6
Grant overlay and Accessibility. Open app, tap `3. TAMPILKAN TOMBOL MENGAMBANG`, then `4. IZINKAN TANGKAP LAYAR`. The floating controls should appear. TEST KAIL sends a single tap at a provisional landscape position.
