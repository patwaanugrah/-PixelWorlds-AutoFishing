plugins { id("com.android.application") }
android { namespace = "com.pw.autofishing"; compileSdk = 35
 defaultConfig { applicationId = "com.pw.autofishing"; minSdk = 29; targetSdk = 35; versionCode = 3; versionName = "1.2-overlay-capture-test" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
