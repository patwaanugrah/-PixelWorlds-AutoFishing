package com.pw.autofishing;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class OverlayService extends Service {
 private WindowManager wm; private View panel; private WindowManager.LayoutParams lp;
 private TextView label; private Button start;
 private void render(){boolean running=CaptureService.enabled;label.setText("PW Fishing v1.2 • "+(running?"RUNNING":"STOPPED"));start.setText(running?"STOP":"START");}
 @Override public int onStartCommand(Intent i,int f,int id){
  if(!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY;}
  if(panel!=null){render();return START_STICKY;}
  wm=(WindowManager)getSystemService(WINDOW_SERVICE);
  LinearLayout ll=new LinearLayout(this);ll.setOrientation(LinearLayout.VERTICAL);ll.setPadding(12,8,12,8);ll.setBackgroundColor(0xE51D2935);
  label=new TextView(this);label.setTextColor(-1);ll.addView(label);
  start=new Button(this);ll.addView(start);
  start.setOnClickListener(v->{CaptureService.enabled=!CaptureService.enabled;render();});
  Button test=new Button(this);test.setText("TEST KAIL");ll.addView(test);
  test.setOnClickListener(v->{FishAccessibility a=FishAccessibility.instance;if(a!=null){android.util.DisplayMetrics d=getResources().getDisplayMetrics();a.tap(d.widthPixels*.892f,d.heightPixels*.84f,90);Toast.makeText(this,"Tap test dikirim",Toast.LENGTH_SHORT).show();}else Toast.makeText(this,"Accessibility belum aktif",Toast.LENGTH_SHORT).show();});
  Button close=new Button(this);close.setText("TUTUP");ll.addView(close);close.setOnClickListener(v->stopSelf());
  lp=new WindowManager.LayoutParams(-2,-2,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);lp.gravity=Gravity.TOP|Gravity.START;lp.x=35;lp.y=80;
  label.setOnTouchListener(new View.OnTouchListener(){int x,y;float sx,sy;public boolean onTouch(View v,MotionEvent e){if(e.getAction()==0){x=lp.x;y=lp.y;sx=e.getRawX();sy=e.getRawY();return true;}if(e.getAction()==1||e.getAction()==2){lp.x=x+(int)(e.getRawX()-sx);lp.y=y+(int)(e.getRawY()-sy);wm.updateViewLayout(panel,lp);return true;}return false;}});
  panel=ll;wm.addView(panel,lp);render();return START_STICKY;
 }
 @Override public void onDestroy(){CaptureService.enabled=false;if(panel!=null){wm.removeView(panel);panel=null;}super.onDestroy();}
 @Override public IBinder onBind(Intent i){return null;}
}
