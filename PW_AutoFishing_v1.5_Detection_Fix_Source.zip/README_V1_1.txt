Pixel Worlds Auto Fishing v1.1 - Overlay Test

PERINGATAN: Ini versi uji tombol mengambang. START (TEST) hanya mengganti status. Belum mengontrol game, tidak mengirim tap dan belum auto fishing.

Cara uji di POCO F6:
1. Instal APK hasil GitHub Actions.
2. Buka aplikasi dan aktifkan izin overlay.
3. Tekan "3. Tampilkan tombol mengambang".
4. Buka Pixel Worlds, lihat panel START (TEST)/STOP.
5. Seret teks status untuk memindahkan panel; TUTUP OVERLAY untuk menutup.

GitHub: unggah ZIP ini di root repository sebagai PixelWorlds_AutoFishing_GitHub_Ready_v1.1.zip.
Workflow .github/workflows/build-apk.yml dalam repo harus diubah menjadi workflow dari file GITHUB_WORKFLOW_V1_1.yml di luar ZIP.
