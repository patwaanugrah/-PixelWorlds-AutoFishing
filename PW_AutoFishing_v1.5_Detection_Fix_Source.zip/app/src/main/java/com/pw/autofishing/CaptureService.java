package com.pw.autofishing;
import android.app.*;import android.content.*;import android.content.pm.ServiceInfo;import android.graphics.*;import android.hardware.display.*;import android.media.*;import android.media.projection.*;import android.os.*;import android.view.*;
public class CaptureService extends Service {
 public static volatile long frames=0;
 private MediaProjection projection;private VirtualDisplay display;private ImageReader reader;private HandlerThread thread;private Handler handler;private Bitmap bitmap;private long lastFrame;
 @Override public void onCreate(){super.onCreate();NotificationChannel c=new NotificationChannel("pw_capture","PW Capture",NotificationManager.IMPORTANCE_LOW);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}
 @Override public int onStartCommand(Intent i,int flags,int id){
  if(i==null||!i.hasExtra("data")){stopSelf();return START_NOT_STICKY;}
  Notification n=new Notification.Builder(this,"pw_capture").setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("PW Fishing v1.3").setContentText("Screen capture active").build();
  startForeground(2026,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
  MediaProjectionManager mgr=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
  Intent data=i.getParcelableExtra("data");projection=mgr.getMediaProjection(i.getIntExtra("result",0),data);
  if(projection==null){stopSelf();return START_NOT_STICKY;}
  projection.registerCallback(new MediaProjection.Callback(){@Override public void onStop(){stopSelf();}},new Handler(Looper.getMainLooper()));
  android.util.DisplayMetrics dm=getResources().getDisplayMetrics();int w=dm.widthPixels,h=dm.heightPixels;
  thread=new HandlerThread("pw-capture");thread.start();handler=new Handler(thread.getLooper());
  reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);
  reader.setOnImageAvailableListener(r->{Image im=r.acquireLatestImage();if(im==null)return;try{
   frames++;long now=SystemClock.uptimeMillis();if(now-lastFrame<140||!FishingEngine.running)return;lastFrame=now;
   Image.Plane plane=im.getPlanes()[0];int stride=plane.getRowStride(),pixelStride=plane.getPixelStride();int padded=stride/pixelStride;
   if(bitmap==null||bitmap.getWidth()!=padded||bitmap.getHeight()!=im.getHeight())bitmap=Bitmap.createBitmap(padded,im.getHeight(),Bitmap.Config.ARGB_8888);
   plane.getBuffer().rewind();bitmap.copyPixelsFromBuffer(plane.getBuffer());
   Bitmap crop=Bitmap.createBitmap(bitmap,0,0,im.getWidth(),im.getHeight());try{FishingEngine.process(this,crop);}finally{crop.recycle();}
  }catch(Exception ex){android.util.Log.e("PWFishing","Frame processing",ex);}finally{im.close();}},handler);
  display=projection.createVirtualDisplay("PW",w,h,dm.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
  if(android.provider.Settings.canDrawOverlays(this))startService(new Intent(this,OverlayService.class));
  return START_NOT_STICKY;
 }
 @Override public void onDestroy(){FishingEngine.stop();if(display!=null)display.release();if(reader!=null)reader.close();if(projection!=null){MediaProjection p=projection;projection=null;p.stop();}if(thread!=null)thread.quitSafely();super.onDestroy();}
 @Override public IBinder onBind(Intent i){return null;}
}
