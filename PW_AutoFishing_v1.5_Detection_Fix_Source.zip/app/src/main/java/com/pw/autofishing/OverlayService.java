package com.pw.autofishing;
import android.app.Service;import android.content.Intent;import android.graphics.PixelFormat;import android.os.*;import android.provider.Settings;import android.view.*;import android.widget.*;

public class OverlayService extends Service {
 private WindowManager wm;private View panel,calibration;private boolean minimized=false;private WindowManager.LayoutParams lp;private TextView label;private Button start;private Handler ui=new Handler(Looper.getMainLooper());
 private final Runnable ticker=new Runnable(){public void run(){render();ui.postDelayed(this,400);}};
 private void render(){if(label!=null){label.setText("PW Fishing v1.4 • "+FishingEngine.state+"\nFrames "+CaptureService.frames+" | fish "+FishingEngine.fishX+" box "+FishingEngine.boxX+"\n"+FishingEngine.diagnostic);start.setText(FishingEngine.running?"STOP":"START");}}
 private Button button(LinearLayout ll,String text,Runnable click){Button b=new Button(this);b.setText(text);ll.addView(b,new LinearLayout.LayoutParams(-1,-2));b.setOnClickListener(v->click.run());return b;}
 @Override public int onStartCommand(Intent i,int f,int id){
  if(!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY;}
  if(panel!=null){render();return START_STICKY;}
  wm=(WindowManager)getSystemService(WINDOW_SERVICE);
  LinearLayout ll=new LinearLayout(this);ll.setOrientation(1);ll.setPadding(8,6,8,6);ll.setBackgroundColor(0xDF182634);
  LinearLayout title=new LinearLayout(this);title.setOrientation(LinearLayout.HORIZONTAL);ll.addView(title);
  label=new TextView(this);label.setTextColor(-1);label.setTextSize(12);label.setPadding(6,12,6,12);title.addView(label,new LinearLayout.LayoutParams(0,-2,1));
  Button minimize=new Button(this);minimize.setText("−");minimize.setMinWidth(0);minimize.setMinimumWidth(0);title.addView(minimize,new LinearLayout.LayoutParams(60,-2));
  LinearLayout controls=new LinearLayout(this);controls.setOrientation(1);ll.addView(controls);
  minimize.setOnClickListener(v->{minimized=!minimized;controls.setVisibility(minimized?View.GONE:View.VISIBLE);minimize.setText(minimized?"+":"−");});
  start=button(controls,"START",()->{if(!FishingEngine.running){if(FishAccessibility.instance==null){Toast.makeText(this,"Aktifkan Accessibility",Toast.LENGTH_SHORT).show();return;}if(CaptureService.frames==0){Toast.makeText(this,"Aktifkan tangkap layar dahulu",Toast.LENGTH_LONG).show();return;}FishingEngine.start();}else FishingEngine.stop();render();});
  button(controls,"TEST KAIL",()->tap("hook",.892f,.875f));
  button(controls,"ATUR KAIL",()->calibrate("hook"));
  button(controls,"ATUR KIRI",()->calibrate("left"));
  button(controls,"ATUR KANAN",()->calibrate("right"));
  button(controls,"ATUR AMBIL IKAN",()->calibrate("take"));
  button(controls,"TUTUP",()->stopSelf());
  lp=new WindowManager.LayoutParams(-2,-2,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
  lp.gravity=Gravity.TOP|Gravity.START;lp.x=getSharedPreferences("pw_settings",0).getInt("panelX",24);lp.y=getSharedPreferences("pw_settings",0).getInt("panelY",50);
  label.setOnTouchListener(new View.OnTouchListener(){int x,y;float sx,sy;public boolean onTouch(View v,MotionEvent e){if(e.getAction()==0){x=lp.x;y=lp.y;sx=e.getRawX();sy=e.getRawY();return true;}if(e.getAction()==1||e.getAction()==2){lp.x=Math.max(0,x+(int)(e.getRawX()-sx));lp.y=Math.max(0,y+(int)(e.getRawY()-sy));wm.updateViewLayout(panel,lp);if(e.getAction()==1)getSharedPreferences("pw_settings",0).edit().putInt("panelX",lp.x).putInt("panelY",lp.y).apply();return true;}return false;}});
  panel=ll;wm.addView(panel,lp);ui.post(ticker);render();return START_STICKY;
 }
 private void tap(String key,float x,float y){FishAccessibility a=FishAccessibility.instance;if(a==null){Toast.makeText(this,"Accessibility belum aktif",Toast.LENGTH_SHORT).show();return;}android.util.DisplayMetrics dm=getResources().getDisplayMetrics();a.tap(FishingEngine.coord(this,key+"X",x)*dm.widthPixels,FishingEngine.coord(this,key+"Y",y)*dm.heightPixels,85);}
 private void calibrate(String key){
  if(calibration!=null)return;
  panel.setVisibility(View.GONE);
  android.util.DisplayMetrics dm=getResources().getDisplayMetrics();
  FrameLayout full=new FrameLayout(this);full.setBackgroundColor(0x33000000);
  TextView instruction=new TextView(this);instruction.setText("SENTUH POSISI TOMBOL "+key.toUpperCase()+" DI GAME");instruction.setTextSize(18);instruction.setTextColor(-1);instruction.setBackgroundColor(0xC0000000);instruction.setPadding(16,12,16,12);full.addView(instruction);
  WindowManager.LayoutParams p=new WindowManager.LayoutParams(-1,-1,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);p.gravity=Gravity.TOP|Gravity.START;
  full.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_UP){float xx=e.getRawX()/dm.widthPixels,yy=e.getRawY()/dm.heightPixels;FishingEngine.save(this,key+"X",Math.max(0,Math.min(1,xx)));FishingEngine.save(this,key+"Y",Math.max(0,Math.min(1,yy)));wm.removeView(full);calibration=null;panel.setVisibility(View.VISIBLE);Toast.makeText(this,key+" disimpan",Toast.LENGTH_SHORT).show();return true;}return true;});
  calibration=full;wm.addView(full,p);
 }
 @Override public void onDestroy(){FishingEngine.stop();ui.removeCallbacks(ticker);if(calibration!=null){wm.removeView(calibration);calibration=null;}if(panel!=null){wm.removeView(panel);panel=null;}super.onDestroy();}
 @Override public IBinder onBind(Intent i){return null;}
}
