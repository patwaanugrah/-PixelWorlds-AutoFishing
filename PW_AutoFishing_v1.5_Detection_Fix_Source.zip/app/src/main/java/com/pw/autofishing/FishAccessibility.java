package com.pw.autofishing;
import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;
public class FishAccessibility extends AccessibilityService {
 public static volatile FishAccessibility instance;
 @Override public void onServiceConnected(){instance=this;}
 @Override public void onAccessibilityEvent(AccessibilityEvent e){}
 @Override public void onInterrupt(){}
 @Override public void onDestroy(){instance=null;super.onDestroy();}
 public boolean tap(float x,float y,long hold){Path path=new Path();path.moveTo(x,y);GestureDescription.StrokeDescription stroke=new GestureDescription.StrokeDescription(path,0,Math.max(40,hold));GestureDescription.Builder b=new GestureDescription.Builder();b.addStroke(stroke);return dispatchGesture(b.build(),null,null);}
}