package com.pw.autofishing;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.SystemClock;

/** Pixel-based fishing controller. Thresholds are provisional and must be calibrated in-game. */
public final class FishingEngine {
 public static volatile String state="STOPPED",diagnostic="";
 public static volatile boolean running=false;
 public static volatile int fishX=-1,boxX=-1;
 private static final String PREF="pw_settings";
 private static long entered=0,lastInput=0,lastFight=0,lastPopup=0;
 private static int fightFrames=0,popupFrames=0,strikeFrames=0;
 private FishingEngine(){}
 public static synchronized void start(){running=true;move("CAST");}
 public static synchronized void stop(){running=false;state="STOPPED";fishX=boxX=-1;}
 public static float coord(Context c,String key,float def){return c.getSharedPreferences(PREF,0).getFloat(key,def);}
 public static void save(Context c,String key,float v){c.getSharedPreferences(PREF,0).edit().putFloat(key,v).apply();}
 private static void move(String next){state=next;entered=SystemClock.uptimeMillis();lastInput=0;fightFrames=popupFrames=strikeFrames=0;}
 private static boolean press(Context c,String key,float dx,float dy,int w,int h,int ms){
  FishAccessibility a=FishAccessibility.instance;
  if(a==null)return false;
  return a.tap(coord(c,key+"X",dx)*w,coord(c,key+"Y",dy)*h,ms);
 }
 private static boolean green(int p){int r=(p>>16)&255,g=(p>>8)&255,b=p&255;return g>145&&g>r*1.35&&g>b*1.20;}
 private static boolean blue(int p){int r=(p>>16)&255,g=(p>>8)&255,b=p&255;return b>115&&b>r*1.25&&b>g*1.07&&g>45;}
 private static boolean orange(int p){int r=(p>>16)&255,g=(p>>8)&255,b=p&255;return r>175&&g>85&&g<205&&b<100;}
 private static int count(Bitmap b,float l,float t,float r,float bt,int step,int kind){
  int w=b.getWidth(),h=b.getHeight(),n=0;
  for(int y=(int)(h*t);y<(int)(h*bt);y+=step)for(int x=(int)(w*l);x<(int)(w*r);x+=step){
   int p=b.getPixel(x,y);if((kind==0&&green(p))||(kind==1&&blue(p))||(kind==2&&orange(p)))n++;
  }
  return n;
 }
 public static void process(Context c,Bitmap b){
  if(!running)return;
  int w=b.getWidth(),h=b.getHeight();
  if(w<=h){state="WAIT LANDSCAPE";return;}
  if(FishAccessibility.instance==null){state="NEED ACCESSIBILITY";return;}
  long now=SystemClock.uptimeMillis();
  // Analyze only the top fishing HUD, not the scenery or overlay.
  int x0=(int)(w*.28),x1=(int)(w*.73),y0=(int)(h*.085),y1=(int)(h*.27);
  int blueCount=0,greenCount=0,orangeCount=0;
  long gx=0,ox=0;
  for(int y=y0;y<y1;y+=2)for(int x=x0;x<x1;x+=2){
   int p=b.getPixel(x,y);
   if(blue(p))blueCount++;
   if(green(p)){greenCount++;gx+=x;}
   if(orange(p)){orangeCount++;ox+=x;}
  }
  fishX=greenCount>=10?(int)(gx/greenCount):-1;
  boxX=orangeCount>=10?(int)(ox/orangeCount):-1;
  // A fight needs both a sizable blue meter and its moving marker.
  boolean fight=blueCount>110&&greenCount>12;
  // Catch window appears in center, not in the top HUD.
  int popupBlue=count(b,.36f,.32f,.65f,.72f,7,1);
  boolean popup=popupBlue>135;
  // A brief green strike signal in the upper-middle, without the full fight HUD.
  int strikeGreen=count(b,.34f,.16f,.67f,.40f,4,0);
  boolean strike=!fight&&strikeGreen>32;
  fightFrames=fight?Math.min(5,fightFrames+1):0;
  popupFrames=popup?Math.min(5,popupFrames+1):0;
  strikeFrames=strike?Math.min(5,strikeFrames+1):0;
  diagnostic="blue="+blueCount+" green="+greenCount+" orange="+orangeCount+" strike="+strikeGreen;
  if(popupFrames>=3&&!state.equals("CATCH")){move("CATCH");lastPopup=now;}
  switch(state){
   case "CAST":
    if(now-entered>300&&now-lastInput>500){
     if(press(c,"hook",.892f,.875f,w,h,90)){lastInput=now;move("WAIT STRIKE");}
    }
    break;
   case "WAIT STRIKE":
    if(fightFrames>=2){lastFight=now;move("FIGHT");break;}
    if(strikeFrames>=2&&now-lastInput>850){
     if(press(c,"hook",.892f,.875f,w,h,85)){lastInput=now;move("WAIT FIGHT");}
    }
    // No repeated blind tapping while bait is in the water.
    if(now-entered>45000)move("RECAST");
    break;
   case "WAIT FIGHT":
    if(fightFrames>=2){lastFight=now;move("FIGHT");break;}
    if(now-entered>2500)move("WAIT STRIKE");
    break;
   case "FIGHT":
    if(fight){
     lastFight=now;
     if(fishX>=0&&boxX>=0&&now-lastInput>=170){
      int d=fishX-boxX,dead=(int)(w*.014);
      if(Math.abs(d)>dead){
       String key=d<0?"left":"right";
       int duration=Math.min(210,Math.max(75,(int)(Math.abs(d)*.55)));
       if(press(c,key,d<0?.108f:.206f,.875f,w,h,duration))lastInput=now;
      }
     }
    }
    if(now-lastFight>1800||now-entered>70000)move("VERIFY");
    break;
   case "VERIFY":
    if(popupFrames>=2){move("CATCH");break;}
    if(fightFrames>=2){lastFight=now;move("FIGHT");break;}
    if(now-entered>2600)move("RECAST");
    break;
   case "CATCH":
    if(now-lastInput>1100){if(press(c,"take",.5f,.75f,w,h,95))lastInput=now;}
    if(!popup&&now-entered>1200)move("RECAST");
    if(now-entered>9000)move("RECAST");
    break;
   case "RECAST":
    if(now-entered>1400)move("CAST");
    break;
  }
 }
}
