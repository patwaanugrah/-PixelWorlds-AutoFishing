# Pixel Worlds Auto Fishing v1.4 — experimental

Based on v1.3. Adds a **− / +** button to minimize/restore the floating control panel, keeps dragging via title, adds calibratable Take Fish coordinate, and revises the visual state machine using upper blue meter, green marker, and lower orange/yellow indicator.

**Not validated on POCO F6**: image heuristics may misread UI; Strike timing and fight steering need in-game testing. Stop if unexpected input occurs.

## Build
Upload this ZIP to the repository root and use the included `.github/workflows/build-apk.yml`. Download the debug APK from the successful Actions run artifact.

## Use
Enable Overlay + Accessibility + Capture; choose Pixel Worlds when Android asks. In the game, calibrate KAIL/KIRI/KANAN/AMBIL IKAN, drag panel by title and press − to minimize; + to restore. Start only after capture is active.
