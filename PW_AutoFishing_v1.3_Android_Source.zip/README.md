# Pixel Worlds Auto Fishing Android v1.3 — EXPERIMENTAL

This is a genuine code change to the supplied v1.2 source, not a finished or tested fishing bot.

Features:
- Movable floating START/STOP/TEST panel (drag the title; position saved)
- Calibration overlays: ATUR KAIL, ATUR KIRI, ATUR KANAN (tap game control centers; saved)
- MediaProjection screenshot processing and Accessibility taps
- Experimental CAST / WAIT STRIKE / FIGHT / CATCH / RECAST state machine
- Green meter heuristic and rough dark-pixel fish estimator. **Not reliable yet**: the scene may be mistaken for fish; huge fish is not validated.

Usage: allow overlay, Accessibility, then capture. Android 16 screen capture: choose Entire screen if available; selecting just Pixel Worlds may return blank when overlay appears. Open game, drag panel by title, calibrate controls, then START. If control is erratic, STOP immediately.

Important: fishing rod must be selected in game. Overlay controls may interfere with capture. Calibration uses device pixel metrics and might require refinement on POCO F6. No root.

Build: GitHub Actions workflow included in `.github/workflows/build-apk.yml`. Upload this source ZIP to repository root as `PW_AutoFishing_v1.3_Android_Source.zip`; workflow unzips and builds debug APK.
