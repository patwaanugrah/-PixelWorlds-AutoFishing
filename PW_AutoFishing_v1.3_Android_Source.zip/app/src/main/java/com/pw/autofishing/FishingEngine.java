package com.pw.autofishing;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.SystemClock;

/** Experimental image-driven controller. No game memory access. */
public final class FishingEngine {
 public static volatile String state="STOPPED";
 public static volatile boolean running=false;
 public static volatile int fishX=-1,boxX=-1;
 private static long lastAction=0, phaseStart=0, lastFishSeen=0;
 private static int confirmations=0, lastDirection=0;
 private static final String PREF="pw_settings";
 private FishingEngine(){}
 public static void start(){running=true;state="CAST";phaseStart=SystemClock.uptimeMillis();lastAction=0;confirmations=0;}
 public static void stop(){running=false;state="STOPPED";fishX=-1;boxX=-1;}
 public static float coord(Context c,String key,float def){return c.getSharedPreferences(PREF,0).getFloat(key,def);}
 public static void save(Context c,String key,float value){c.getSharedPreferences(PREF,0).edit().putFloat(key,value).apply();}
 private static void press(Context c,String name,float defX,float defY,long ms,int w,int h){FishAccessibility a=FishAccessibility.instance;if(a!=null)a.tap(coord(c,name+"X",defX)*w,coord(c,name+"Y",defY)*h,ms);}
 private static boolean eligible(long now,long delay){return now-lastAction>=delay;}
 private static void next(String s,long now){state=s;phaseStart=now;confirmations=0;lastAction=0;}
 public static void process(Context c,Bitmap b){
  if(!running)return;
  FishAccessibility a=FishAccessibility.instance;
  if(a==null){state="NEED ACCESSIBILITY";return;}
  int w=b.getWidth(),h=b.getHeight();if(w<h){state="WAIT LANDSCAPE";return;}
  long now=SystemClock.uptimeMillis();
  // UI position model: upper fishing meter in 28%-72% of screen width, 9%-29% height.
  // Calibrated by detecting saturated green zone and contrasting fish icon; heuristic, not a trained model.
  int left=(int)(w*.28),right=(int)(w*.72),top=(int)(h*.09),bottom=(int)(h*.29);
  long greenSum=0,darkSum=0;int greenN=0,darkN=0;
  for(int y=top;y<bottom;y+=3){for(int x=left;x<right;x+=3){int p=b.getPixel(x,y);int r=(p>>16)&255,g=(p>>8)&255,bl=p&255;
   if(g>100&&g>r*1.42&&g>bl*1.22){greenSum+=x;greenN++;}
   if(r<83&&g<83&&bl<83){darkSum+=x;darkN++;}
  }}
  boxX=greenN>25?(int)(greenSum/greenN):-1;
  // Dark pixels are numerous in game scenery. Require a green meter before using a dark-fish estimate.
  fishX=greenN>25&&darkN>15?(int)(darkSum/darkN):-1;
  boolean meter=greenN>25;
  switch(state){
   case "CAST":
    if(eligible(now,700)){press(c,"hook",.892f,.875f,90,w,h);lastAction=now;next("WAIT STRIKE",now);}break;
   case "WAIT STRIKE":
    if(meter){if(++confirmations>=2)next("FIGHT",now);}
    else confirmations=0;
    // Experimental: tap hook periodically while waiting. Game-specific strike cue needs validation.
    if(eligible(now,1800)&&now-phaseStart>1600){press(c,"hook",.892f,.875f,70,w,h);lastAction=now;}
    if(now-phaseStart>30000)next("CAST",now);
    break;
   case "FIGHT":
    if(meter){lastFishSeen=now;
     if(fishX>=0&&boxX>=0&&eligible(now,170)){
      int dir=fishX<boxX-w*.018?-1:fishX>boxX+w*.018?1:0;
      if(dir!=0){press(c,dir<0?"left":"right",dir<0?.108f:.206f,.875f,130,w,h);lastAction=now;lastDirection=dir;}
     }
    }else if(now-lastFishSeen>1100)next("CATCH",now);
    if(now-phaseStart>50000)next("CATCH",now);
    break;
   case "CATCH":
    if(eligible(now,1100)){press(c,"hook",.892f,.875f,80,w,h);lastAction=now;}
    if(now-phaseStart>2700)next("RECAST",now);
    break;
   case "RECAST":if(now-phaseStart>650)next("CAST",now);break;
  }
 }
}
