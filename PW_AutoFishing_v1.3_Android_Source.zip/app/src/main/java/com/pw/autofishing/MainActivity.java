package com.pw.autofishing;
import android.app.Activity;import android.content.*;import android.media.projection.MediaProjectionManager;import android.os.Bundle;import android.provider.Settings;import android.net.Uri;import android.widget.*;
public class MainActivity extends Activity {
 private static final int REQ=101;private TextView status;private MediaProjectionManager mgr;
 @Override public void onCreate(Bundle b){super.onCreate(b);mgr=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(24,36,24,16);status=new TextView(this);status.setText("PW Fishing v1.3 • EXPERIMENTAL AUTO\nOverlay + Capture + Accessibility");l.addView(status);
 add(l,"1. IZIN OVERLAY",()->startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()))));
 add(l,"2. AKTIFKAN ACCESSIBILITY",()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
 add(l,"3. TAMPILKAN TOMBOL MENGAMBANG",()->{if(Settings.canDrawOverlays(this)){startService(new Intent(this,OverlayService.class));status.setText("Overlay aktif. Buka Pixel Worlds.");}else status.setText("Izin overlay belum aktif");});
 add(l,"4. IZINKAN TANGKAP LAYAR",()->startActivityForResult(mgr.createScreenCaptureIntent(),REQ));
 add(l,"STOP SEMUA",()->{stopService(new Intent(this,CaptureService.class));stopService(new Intent(this,OverlayService.class));status.setText("STOPPED");});
 TextView note=new TextView(this);note.setText("PENTING: START menjalankan alur otomatis eksperimental. Geser panel lewat judul; ATUR KAIL/KIRI/KANAN untuk kalibrasi. Deteksi Strike/Huge Fish masih perlu diuji.");l.addView(note);setContentView(l);}
 private void add(LinearLayout l,String title,Runnable r){Button b=new Button(this);b.setText(title);b.setOnClickListener(v->r.run());l.addView(b);}
 @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req==REQ&&result==RESULT_OK&&data!=null){Intent i=new Intent(this,CaptureService.class);i.putExtra("result",result);i.putExtra("data",data);startForegroundService(i);status.setText("Capture requested. Buka Pixel Worlds, tekan START pada overlay.");}}
}
