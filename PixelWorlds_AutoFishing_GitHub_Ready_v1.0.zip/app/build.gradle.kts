plugins { id("com.android.application") }
android { namespace = "com.pw.autofishing"; compileSdk = 35
 defaultConfig { applicationId = "com.pw.autofishing"; minSdk = 29; targetSdk = 35; versionCode = 1; versionName = "1.0-dev" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
