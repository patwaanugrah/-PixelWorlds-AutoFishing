# Pixel Worlds Auto Fishing Android v1.0 DEV — POCO F6

**Status: SOURCE PROJECT / PROTOTYPE, BUKAN APK SIAP PAKAI.**

## Sudah diimplementasikan
- Proyek Android Studio Java, minimum Android 10 (API 29), target API 35.
- Permintaan izin overlay dan pengaturan Accessibility.
- Permintaan izin MediaProjection melalui dialog Android.
- Foreground service dan pembacaan frame layar (frame langsung ditutup).
- Metode gesture tap Accessibility (belum dipanggil otomatis demi keamanan pengujian).
- Tombol STOP.

## Belum diimplementasikan / diuji
- Overlay floating START/STOP (izin disiapkan, overlay belum dibuat).
- Pengenalan Strike, fish bar, posisi ikan, kotak hijau, LAND THE FISH.
- State machine Auto Cast / Strike / Fight / Catch / Recast.
- Kalibrasi koordinat untuk POCO F6 dan pengujian di perangkat.
- APK hasil build.

## Build
1. Buka folder ini dengan Android Studio versi yang mendukung Android Gradle Plugin 8.7.3, JDK 17 dan Android SDK 35.
2. Sync Gradle dengan koneksi internet.
3. Build > Build APK(s).
4. Instal hanya untuk pengujian; aplikasi saat ini hanya mengamati layar dan tidak memancing otomatis.

## Catatan
Android 14+ mensyaratkan persetujuan MediaProjection setiap sesi dan foreground service yang sesuai. Accessibility harus diaktifkan secara manual oleh pemilik perangkat. Jangan gunakan hasil prototipe ini untuk mengklaim fitur Auto Fishing telah berfungsi.
