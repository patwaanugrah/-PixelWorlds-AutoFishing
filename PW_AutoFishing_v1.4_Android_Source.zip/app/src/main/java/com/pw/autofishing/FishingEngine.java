package com.pw.autofishing;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.SystemClock;

/** Experimental visual state machine, operates on screen pixels only. */
public final class FishingEngine {
 public static volatile String state="STOPPED";
 public static volatile boolean running=false;
 public static volatile int fishX=-1,boxX=-1;
 private static long lastAction=0,phaseStart=0,lastMeter=0;
 private static int stableMeter=0,stablePopup=0;
 private static final String PREF="pw_settings";
 private FishingEngine(){}
 public static void start(){running=true;transition("CAST",SystemClock.uptimeMillis());}
 public static void stop(){running=false;state="STOPPED";fishX=boxX=-1;}
 public static float coord(Context c,String key,float def){return c.getSharedPreferences(PREF,0).getFloat(key,def);}
 public static void save(Context c,String key,float v){c.getSharedPreferences(PREF,0).edit().putFloat(key,v).apply();}
 private static void transition(String s,long now){state=s;phaseStart=now;lastAction=0;stableMeter=stablePopup=0;}
 private static void tap(Context c,String key,float x,float y,int w,int h,int ms){FishAccessibility a=FishAccessibility.instance;if(a!=null)a.tap(coord(c,key+"X",x)*w,coord(c,key+"Y",y)*h,ms);}
 private static boolean blue(int p){int r=(p>>16)&255,g=(p>>8)&255,b=p&255;return b>90&&b>r*1.3&&b>g*1.07&&g>45;}
 private static boolean green(int p){int r=(p>>16)&255,g=(p>>8)&255,b=p&255;return g>110&&g>r*1.35&&g>b*1.15;}
 private static boolean yellow(int p){int r=(p>>16)&255,g=(p>>8)&255,b=p&255;return r>155&&g>90&&b<110&&r>b*1.8;}
 public static void process(Context c,Bitmap b){
  if(!running)return;
  if(FishAccessibility.instance==null){state="NEED ACCESSIBILITY";return;}
  int w=b.getWidth(),h=b.getHeight();if(w<=h){state="WAIT LANDSCAPE";return;}
  long now=SystemClock.uptimeMillis();
  // The recording shows a horizontal blue fight meter in the upper-middle,
  // a bright green fish marker on it, and an orange/yellow lower indicator.
  int x0=(int)(w*.27),x1=(int)(w*.73),y0=(int)(h*.035),y1=(int)(h*.23);
  int blues=0,greens=0,yellows=0;long greenX=0,yellowX=0;
  for(int y=y0;y<y1;y+=3)for(int x=x0;x<x1;x+=3){
   int p=b.getPixel(x,y);
   if(blue(p))blues++;
   if(green(p)){greens++;greenX+=x;}
   if(yellow(p)){yellows++;yellowX+=x;}
  }
  boolean meter=blues>90&&greens>8;
  fishX=greens>8?(int)(greenX/greens):-1;
  boxX=yellows>8?(int)(yellowX/yellows):-1;
  // Catch popup: central cyan/blue window, with large blue region below meter.
  int popupBlue=0;
  for(int y=(int)(h*.31);y<(int)(h*.72);y+=7)
   for(int x=(int)(w*.36);x<(int)(w*.65);x+=7)
    if(blue(b.getPixel(x,y)))popupBlue++;
  boolean popup=popupBlue>135;
  stableMeter=meter?Math.min(6,stableMeter+1):Math.max(0,stableMeter-1);
  stablePopup=popup?Math.min(6,stablePopup+1):Math.max(0,stablePopup-1);
  if(stablePopup>=3&& !state.equals("CATCH"))transition("CATCH",now);
  switch(state){
   case "CAST":
    if(now-lastAction>700){tap(c,"hook",.892f,.875f,w,h,85);lastAction=now;transition("WAIT STRIKE",now);}
    break;
   case "WAIT STRIKE":
    // On many fishing scenes, FISH ON appears only after pressing hook on strike.
    // Periodic strike tap remains experimental; no blind rapid tapping.
    if(stableMeter>=2){lastMeter=now;transition("FIGHT",now);break;}
    if(now-phaseStart>2000&&now-lastAction>2200){tap(c,"hook",.892f,.875f,w,h,65);lastAction=now;}
    if(now-phaseStart>35000)transition("CAST",now);
    break;
   case "FIGHT":
    if(meter){lastMeter=now;
     if(fishX>=0&&boxX>=0&&now-lastAction>140){
      int dead=(int)(w*.016);int delta=fishX-boxX;
      if(Math.abs(delta)>dead){
       String key=delta<0?"left":"right";
       tap(c,key,delta<0?.108f:.206f,.875f,w,h,Math.min(175,Math.max(65,Math.abs(delta)*110/w)));
       lastAction=now;
      }
     }
    }
    if(now-lastMeter>1200||now-phaseStart>65000)transition("VERIFY RESULT",now);
    break;
   case "VERIFY RESULT":
    if(stablePopup>=2){transition("CATCH",now);break;}
    if(stableMeter>=2){transition("FIGHT",now);break;}
    if(now-phaseStart>2200)transition("RECAST",now);
    break;
   case "CATCH":
    // Center-lower 'Ambil Ikan' button on recorded popup; calibratable.
    if(now-lastAction>1000){tap(c,"take",.5f,.75f,w,h,80);lastAction=now;}
    if(stablePopup==0&&now-phaseStart>1000)transition("RECAST",now);
    break;
   case "RECAST":if(now-phaseStart>900)transition("CAST",now);break;
  }
 }
}
